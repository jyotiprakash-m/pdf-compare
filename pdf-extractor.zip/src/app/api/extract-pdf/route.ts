import { NextRequest, NextResponse } from 'next/server';
import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';
import os from 'os';
import { v4 as uuidv4 } from 'uuid';

const execAsync = promisify(exec);

export async function POST(request: NextRequest) {
  try {
    const { url } = await request.json();

    if (!url) {
      return NextResponse.json(
        { error: 'PDF URL is required' },
        { status: 400 }
      );
    }

    // Validate URL format
    try {
      new URL(url);
    } catch (error) {
      return NextResponse.json(
        { error: 'Invalid URL format' },
        { status: 400 }
      );
    }

    // Create temporary directory for processing
    const tempDir = path.join(os.tmpdir(), uuidv4());
    const pdfPath = path.join(tempDir, 'document.pdf');
    const textPath = path.join(tempDir, 'document.txt');

    try {
      // Create temp directory
      await fs.promises.mkdir(tempDir, { recursive: true });

      // Download the PDF file
      console.log(`Downloading PDF from ${url}`);
      await execAsync(`curl -L "${url}" -o "${pdfPath}"`);

      // Check if file was downloaded and is a PDF
      const fileStats = await fs.promises.stat(pdfPath);
      if (fileStats.size === 0) {
        throw new Error('Downloaded file is empty');
      }

      // Use pdftotext from poppler-utils to extract text
      console.log('Extracting text from PDF');
      await execAsync(`pdftotext "${pdfPath}" "${textPath}"`);

      // Read the extracted text
      const extractedText = await fs.promises.readFile(textPath, 'utf-8');

      // Clean up temporary files
      fs.promises.rm(tempDir, { recursive: true, force: true })
        .catch(err => console.error('Error cleaning up temp files:', err));

      return NextResponse.json({ text: extractedText });
    } catch (error) {
      // Clean up temporary files on error
      fs.promises.rm(tempDir, { recursive: true, force: true })
        .catch(err => console.error('Error cleaning up temp files:', err));

      console.error('PDF processing error:', error);
      throw error;
    }
  } catch (error) {
    console.error('API error:', error);
    return NextResponse.json(
      { error: 'Failed to extract text from PDF' },
      { status: 500 }
    );
  }
}
