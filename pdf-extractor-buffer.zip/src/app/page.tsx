'use client';

import { useState } from "react";
import Image from "next/image";

export default function Home() {
  const [url, setUrl] = useState('');
  const [extractedText, setExtractedText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!url) {
      setError('Please enter a PDF URL');
      return;
    }

    try {
      setIsLoading(true);
      setError('');
      setExtractedText('');
      
      const response = await fetch('/api/extract-pdf', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ url }),
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to extract text from PDF');
      }

      setExtractedText(data.text);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen p-8 max-w-4xl mx-auto">
      <header className="mb-8 text-center">
        <h1 className="text-3xl font-bold mb-2">PDF Text Extractor</h1>
        <p className="text-gray-600 dark:text-gray-400">Extract text from any PDF using its URL</p>
      </header>

      <main className="space-y-8">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="pdf-url" className="block text-sm font-medium mb-1">
              PDF URL
            </label>
            <input
              id="pdf-url"
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://example.com/document.pdf"
              className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>
          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? 'Extracting...' : 'Extract Text'}
          </button>
        </form>

        {error && (
          <div className="p-4 bg-red-50 border border-red-200 rounded-md text-red-600">
            {error}
          </div>
        )}

        {extractedText && (
          <div className="space-y-2">
            <h2 className="text-xl font-semibold">Extracted Text</h2>
            <div className="p-4 bg-gray-50 dark:bg-gray-800 border rounded-md max-h-96 overflow-y-auto whitespace-pre-wrap">
              {extractedText}
            </div>
          </div>
        )}

        <div className="text-center text-sm text-gray-500 mt-8">
          <p>This application extracts text from PDF documents using their URLs.</p>
          <p>Simply paste a PDF URL above and click "Extract Text".</p>
        </div>
      </main>

      <footer className="mt-12 pt-6 border-t text-center text-sm text-gray-500">
        <p>PDF Text Extractor - Built with Next.js</p>
      </footer>
    </div>
  );
}
